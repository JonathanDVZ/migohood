<div id="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-left">
                <br><strong>Category</strong><br>
                <br>
                <a href="">SPACES</a><br>
                <a href="">WORKSPACES</a><br>
                <a href="">PARKING SPACES</a><br>
                <a href="">SERVICES</a><br>
                <a href="">HOST</a><br>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-left">
                <br><strong class="text-center">Help</strong><br>
                <br>
                <a href="">HELP</a><br>
                <a href="">TERMS AND CONDITIONS</a><br>
                <a href="">GUEST AND REFUND</a><br>
                <a href="">PRIVACY POLICY</a><br>
                <a href="">CONTACT US</a><br>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-left ">
                <br><strong class="text-center">About</strong><br>
                <br>
                <a href="">HOW IT WORKS?</a><br>
                <a href="">ABOUT US</a><br>
                <a href="">PRICING</a><br>
                <a href="">PAYMENT FLOW</a><br>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center">
                <br><img class="img-responsive text-center wlogo" src="{{url('/assets/img/wlogo.png')}}" alt="White Migohood Logo">
            </div>
        </div>
    </div>
    <div class="footD">
        <p class="small text-center">&copy; 2017 Migohood LLC All rights reserved.</p>
    </div>
</div>